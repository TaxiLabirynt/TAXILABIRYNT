ICON_ICO = "images/icon.ico"
ICON_PNG = "icon.png"

# Links
APP_STORE_LINK = "https://apps.apple.com"
PLAY_STORE_LINK = "https://play.google.com"

# UI text
SITE_NAME = "Таксі лабіринт"
SLOGAN = "Замовляй вигідно, приїзджай вчасно"
